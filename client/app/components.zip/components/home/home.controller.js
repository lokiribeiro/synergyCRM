'use strict';

angular.module(app.name).controller('HomeController', function ($scope) {
  console.log('Hello from Home Controller')
});
